import UIKit

//first task introduction func
func introduction(name : String , home : String , age : Int ){
    print("\(name) , \(age) , is from \(home)")
}
introduction(name: "omar" ,home: "cairo" ,age: 24 )





//second task cheak num
func getOddEvennum(num : Int){
   
        if(num%2==0){
            print("\(num) is even number")
        }
    else{
            print("\(num) is odd number")
    }
}

getOddEvennum(num: 96)
getOddEvennum(num: 440)




//third task calculate Crade
func calculateGrade(stuGrade : Int , totalgrade : Int) -> String{
    var result = Double(stuGrade) / Double(totalgrade) * 100
    var degree : String = ""
    if(result > 100){
        print("incorrect degree")
    }
    else{
        switch result {
        case 0...55 :
            degree = "Fail"
        case 56...65 :
            degree = "pass"
        case 66...75 :
            degree = "good"
        case 76...85 :
            degree = "Very good"
        default :
            degree = "Excellent"
        }
    }
return degree
}
print(calculateGrade( stuGrade: 315 , totalgrade: 500 ))


//let temp :Int
//temp = 65
//switch temp{
//case Int.min...65 :
//    print("it too cold")
//case 65...75 :
//    print(" it is right")
//default :
//    print("it is too hot")
//}
